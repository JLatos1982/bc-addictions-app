# BC Addictions Resource App (Starter)

A lightweight starter for a **Next.js 14 (App Router)** web app backed by **Supabase**.
Designed to run entirely from a browser-based dev environment (great for iPad).

## What you can do from iPad
- Use **GitHub Codespaces** or **StackBlitz** to run the app in the browser.
- Use **Supabase Studio** (web UI) to create the database and paste the SQL in `supabase/schema.sql`.
- Deploy with **Vercel** (1-click) using the included config.

## Quick Start
1. Create a new Supabase project. In the SQL editor, paste `supabase/schema.sql`, run it, then (optional) run `supabase/seed.sql`.
2. Grab your `SUPABASE_URL` and `SUPABASE_ANON_KEY` from Supabase > Project Settings > API. Put them into `.env.local`:
   ```
   NEXT_PUBLIC_SUPABASE_URL=...
   NEXT_PUBLIC_SUPABASE_ANON_KEY=...
   ```
3. In a browser-based dev environment (Codespaces / StackBlitz):
   ```bash
   npm install
   npm run dev
   ```
4. Visit the local URL shown (usually `http://localhost:3000`).
5. Deploy with Vercel, set the same env vars there.

## Scripts
- `dev`: local dev server
- `build`: production build
- `start`: start production

## Folders
- `app/` – Next.js routes
- `components/` – UI components
- `lib/` – Supabase client
- `public/data/` – CSV samples (BC resources)
- `supabase/` – SQL schema and seeds

## Notes
- The design uses a soft blue/white palette.
- The hero section text: **Find Addiction Support in BC**.
- Search focuses on location (city) and category.
