
-- Schema for BC Addictions Resource App
create table if not exists public.resources (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null, -- e.g., Detox, OAT, Food Bank, Shelter, Counseling
  description text,
  phone text,
  website text,
  address text,
  city text,
  region text, -- e.g., Lower Mainland, Vancouver Island, Interior, Northern
  postal_code text,
  hours text,
  tags text, -- comma-separated keywords
  created_at timestamp with time zone default now()
);

-- Enable RLS so anon can read but not write
alter table public.resources enable row level security;

create policy "Public read resources"
on public.resources for select
to anon
using (true);

-- (Optional) editor role for writes
-- create role editor;
-- grant usage on schema public to editor;
-- grant all on public.resources to editor;

-- Basic helpful index
create index if not exists resources_city_idx on public.resources using gin ( (to_tsvector('simple', coalesce(city,''))) );
create index if not exists resources_category_idx on public.resources (category);
create index if not exists resources_text_idx on public.resources using gin ( (to_tsvector('english', coalesce(name,'')||' '||coalesce(description,'')||' '||coalesce(tags,''))) );
