
-- Minimal BC sample resources
insert into public.resources (name, category, description, phone, website, address, city, region, postal_code, hours, tags)
values
('BC Alcohol & Drug Information & Referral Service', 'Helpline', '24/7 helpline connecting people to addictions services across BC.', '1-800-663-1441', 'https://www.healthlinkbc.ca/mental-health-substance-use/adu', null, 'Province-wide', 'Province-wide', null, '24/7', 'helpline, province-wide, crisis'),
('811 HealthLink BC', 'Helpline', 'Call 8-1-1 to speak to a nurse or get service navigation.', '811', 'https://www.healthlinkbc.ca', null, 'Province-wide', 'Province-wide', null, '24/7', 'navigation, general'),
('Vancouver Detox (VCH)', 'Detox', 'Medical withdrawal management services.', '604-658-1278', 'https://www.vch.ca', '377 East 2nd Ave', 'Vancouver', 'Lower Mainland', 'V5T 1B7', '24/7 intake', 'detox, withdrawal'),
('Island Health OAT Clinic – Victoria', 'OAT', 'Opioid Agonist Therapy clinic.', '250-370-8699', 'https://www.islandhealth.ca', '1947 Cook St', 'Victoria', 'Vancouver Island', 'V8T 3P6', 'Mon–Fri', 'oat, methadone, suboxone'),
('Salvation Army Harbour Light', 'Recovery', 'Residential treatment and recovery.', '604-646-6800', 'https://centre.salvationarmy.ca', '119 Cordova St E', 'Vancouver', 'Lower Mainland', 'V6A 1K8', '24/7 intake', 'recovery, residential'),
('Prince George Native Friendship Centre – Food Bank', 'Food Bank', 'Food support services.', '250-564-3568', 'https://www.pgnfc.com', '1600 3rd Ave', 'Prince George', 'Northern', 'V2L 3G6', 'Tue–Fri', 'food, indigenous, support');

insert into public.resources (name, category, description, phone, website, address, city, region, postal_code, hours, tags) values
('BC Nurse Line (mental health & substance use)', 'Helpline', 'Access to nurses and navigation for care in BC.', '811', 'https://www.healthlinkbc.ca', null, 'Province-wide', 'Province-wide', null, '24/7', 'navigation, nurse, helpline'),
('Foundry Virtual BC', 'Youth', 'Virtual mental health & substance use services for ages 12–24.', '1-833-308-6379', 'https://foundrybc.ca/virtual', null, 'Province-wide', 'Province-wide', null, 'Mon–Sun', 'youth, virtual, counselling'),
('Insight (Fraser Health)', 'OAT', 'Rapid access to OAT and substance use services.', '604-587-4420', 'https://www.fraserhealth.ca', '2nd Floor, 9639 137A St', 'Surrey', 'Lower Mainland', 'V3T 4J5', 'Mon–Fri', 'oat, methadone, suboxone'),
('SAFER – Vancouver Coastal Health', 'Harm Reduction', 'Supports safer supply and harm reduction services.', '604-657-2121', 'https://www.vch.ca', '1245 Esmond Ave', 'Vancouver', 'Lower Mainland', 'V5K 2Y3', 'Mon–Fri', 'harm reduction, safer supply'),
('Island Health – RAPID OAT Nanaimo', 'OAT', 'Rapid access OAT clinic.', '250-755-7691', 'https://www.islandhealth.ca', '1515 Dufferin Cres', 'Nanaimo', 'Vancouver Island', 'V9S 5K9', 'Mon–Fri', 'oat, rapid access'),
('Interior Health – Withdrawal Management (Kelowna)', 'Detox', 'Inpatient withdrawal management.', '250-868-7788', 'https://www.interiorhealth.ca', '2280 Ethel St', 'Kelowna', 'Interior', 'V1Y 2Z4', '24/7 intake', 'detox, withdrawal'),
('Lookout Society – IHS Harm Reduction', 'Harm Reduction', 'Harm reduction supplies and connections to care.', '604-255-0340', 'https://lookoutsociety.ca', '528 Powell St', 'Vancouver', 'Lower Mainland', 'V6A 1G9', 'Mon–Sun', 'harm reduction, supplies'),
('RainCity Housing – Surrey IHS', 'Shelter', 'Shelter with harm reduction supports.', '604-265-8300', 'https://www.raincityhousing.org', '9155 King George Blvd', 'Surrey', 'Lower Mainland', 'V3V 7Y3', '24/7', 'shelter, harm reduction'),
('Port Alberni Shelter Society – Food Bank', 'Food Bank', 'Food bank and community supports.', '250-723-6511', 'https://www.passbc.ca', '3978 8th Ave', 'Port Alberni', 'Vancouver Island', 'V9Y 4S2', 'Tue–Fri', 'food bank, support'),
('Northern Health – OAT Clinic Prince George', 'OAT', 'OAT and substance use services for the North.', '250-565-2649', 'https://www.northernhealth.ca', '1308 Alward St', 'Prince George', 'Northern', 'V2M 7B1', 'Mon–Fri', 'oat, suboxone');
