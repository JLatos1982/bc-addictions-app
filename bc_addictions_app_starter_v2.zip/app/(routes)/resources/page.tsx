'use client';
import React, { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabaseClient';
import Link from 'next/link';

type Resource = {
  id: string;
  name: string;
  category: string;
  phone: string | null;
  website: string | null;
  city: string | null;
  region: string | null;
  address: string | null;
  hours: string | null;
  description: string | null;
  tags?: string | null;
};

export default function ResourcesPage() {
  const [results, setResults] = useState<Resource[]>([]);
  const [q, setQ] = useState('');
  const [city, setCity] = useState('');
  const [category, setCategory] = useState('');
  const [loading, setLoading] = useState(false);

  async function search() {
    setLoading(true);
    let query = supabase.from('resources').select('*').limit(100);
    if (city) query = query.ilike('city', `%${city}%`);
    if (category) query = query.ilike('category', `%${category}%`);
    if (q) query = query.or(`name.ilike.%${q}%,description.ilike.%${q}%,tags.ilike.%${q}%`);
    const { data, error } = await query;
    if (!error && data) setResults(data as Resource[]);
    setLoading(false);
  }

  useEffect(()=>{ search(); },[]);

  return (
    <div className="container">
      <header style={{display:'grid', gap: 6, marginBottom: 18}}>
        <div style={{fontSize: 32, fontWeight: 800}}>Browse Resources</div>
        <div style={{color:'var(--muted)'}}>Blue/white, soft edges and gentle shadows for a calm, Studio-Ghibli-esque feel.</div>
        <div><Link href="/">← Back to Home</Link></div>
      </header>

      <div className="card ghibli-panel" style={{display:'grid', gap: 8}}>
        <div style={{display:'grid', gap: 8, gridTemplateColumns:'1fr 1fr 1fr'}}>
          <input placeholder="Keywords" value={q} onChange={e=>setQ(e.target.value)} />
          <input placeholder="City (e.g., Victoria)" value={city} onChange={e=>setCity(e.target.value)} />
          <input placeholder="Category (e.g., OAT, Detox)" value={category} onChange={e=>setCategory(e.target.value)} />
        </div>
        <button onClick={search} style={{padding:'10px 14px', borderRadius:12, border:'1px solid #cfe0ff', background:'#e8f0ff'}}>Search</button>
      </div>

      <section style={{marginTop: 18, display:'grid', gap:12}}>
        {loading && <div>Loading...</div>}
        {!loading && results.map((r)=> (
          <article key={r.id} className="card ghibli-card">
            <div style={{display:'flex', justifyContent:'space-between', alignItems:'baseline'}}>
              <h3 style={{margin:0, fontWeight:900}} className="ghibli-title">{r.name}</h3>
              <span style={{fontSize:12, color:'var(--muted)'}}>{r.category}</span>
            </div>
            {r.description && <p style={{margin:'6px 0 0 0'}}>{r.description}</p>}
            <div style={{display:'grid', gap:8, gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))', marginTop:8}}>
              {r.city && <div><strong>City:</strong> {r.city}</div>}
              {r.region && <div><strong>Region:</strong> {r.region}</div>}
              {r.phone && <div><strong>Phone:</strong> {r.phone}</div>}
              {r.website && <div><a href={r.website} target="_blank" rel="noreferrer">Website</a></div>}
              {r.address && <div><strong>Address:</strong> {r.address}</div>}
              {r.hours && <div><strong>Hours:</strong> {r.hours}</div>}
              {r.tags && <div><strong>Tags:</strong> {r.tags}</div>}
            </div>
          </article>
        ))}
        {!loading && results.length === 0 && <div className="card">No results yet. Try different filters.</div>}
      </section>
    </div>
  );
}
