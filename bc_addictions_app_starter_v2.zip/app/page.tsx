'use client';
import React, { useEffect, useState } from 'react';
import SearchBar from '../components/SearchBar';
import { supabase } from '../lib/supabaseClient';

type Resource = {
  tags?: string | null;
  id: string;
  name: string;
  category: string;
  phone: string | null;
  website: string | null;
  city: string | null;
  region: string | null;
  address: string | null;
  hours: string | null;
  description: string | null;
};

export default function Home() {
  const [results, setResults] = useState<Resource[]>([]);
  const [loading, setLoading] = useState(false);

  async function runSearch({city, category, text, browseOnly}: {city?: string, category?: string, text?: string, browseOnly?: boolean}) {
    setLoading(true);
    let query = supabase.from('resources').select('*').limit(50);
    if (city) query = query.ilike('city', `%${city}%`);
    if (category) query = query.ilike('category', `%${category}%`);
    if (text) {
      // basic text search across a few fields
      query = query.or(`name.ilike.%${text}%,description.ilike.%${text}%,tags.ilike.%${text}%`);
    }
    const { data, error } = await query;
    if (!error && data) setResults(data as Resource[]);
    setLoading(false);
  }

  useEffect(()=>{
    runSearch({});
  },[])

  return (
    <div className="container">
      <header style={{display:'grid', gap: 12, marginBottom: 18}}>
        <div style={{fontSize: 36, fontWeight: 800}}>Find Addiction Support in BC</div>
        <div style={{color:'var(--muted)'}}>Browse helplines, clinics, food banks, OAT providers, and more. Blue/white palette for calm and clarity.</div>
      </header>

      <SearchBar onSearch={runSearch} />

      <section style={{marginTop: 18, display:'grid', gap:12}}>
        {loading && <div>Loading...</div>}
        {!loading && results.map((r)=>(
          <article key={r.id} className="card" style={{display:'grid', gap:8}}>
            <div style={{display:'flex', justifyContent:'space-between', alignItems:'baseline'}}>
              <h3 style={{margin:0}}>{r.name}</h3>
              <span style={{fontSize:12, color:'var(--muted)'}}>{r.category}</span>
            </div>
            {r.description && <p style={{margin:0}}>{r.description}</p>}
            <div style={{display:'grid', gap:6, gridTemplateColumns:'repeat(auto-fit,minmax(180px,1fr))'}}>
              {r.city && <div><strong>City:</strong> {r.city}</div>}
              {r.region && <div><strong>Region:</strong> {r.region}</div>}
              {r.phone && <div><strong>Phone:</strong> {r.phone}</div>}
              {r.website && <div><a href={r.website} target="_blank" rel="noreferrer">Website</a></div>}
              {r.address && <div><strong>Address:</strong> {r.address}</div>}
              {r.hours && <div><strong>Hours:</strong> {r.hours}</div>}
              {r.tags && <div><strong>Tags:</strong> {r.tags}</div>}
            </div>
          </article>
        ))}
        {!loading && results.length === 0 && <div className="card">No results yet. Try a broader search.</div>}
      </section>
    </div>
  );
}
