'use client';
import React, { useState } from 'react';

export default function SearchBar({ onSearch }: { onSearch: (q: {city?: string, category?: string, text?: string, browseOnly?: boolean}) => void }) {
  const [city, setCity] = useState('');
  const [category, setCategory] = useState('');
  const [text, setText] = useState('');
  const [browseOnly, setBrowseOnly] = useState(true);

  return (
    <div className="card" style={{display:'grid', gap: 12}}>
      <div style={{fontWeight:600}}>Search resources</div>
      <div style={{display:'grid', gap: 8, gridTemplateColumns: '1fr 1fr'}}>
        <input placeholder="City (e.g., Vancouver)" value={city} onChange={e=>setCity(e.target.value)} />
        <input placeholder="Category (e.g., Detox, OAT, Food Bank)" value={category} onChange={e=>setCategory(e.target.value)} />
      </div>
      <input placeholder="Keywords (e.g., 24/7, phone, youth)" value={text} onChange={e=>setText(e.target.value)} />
      <label style={{display:'flex', alignItems:'center', gap:8}}>
        <input type="checkbox" checked={browseOnly} onChange={(e)=>setBrowseOnly(e.target.checked)} />
        Resource-only browsing (no chat)
      </label>
      <button onClick={()=>onSearch({city, category, text, browseOnly})} style={{padding:'10px 14px', borderRadius:8, border:'1px solid #cfe0ff', background:'#e8f0ff'}}>
        Search
      </button>
    </div>
  );
}
